





//Tabs acordion
$(function(){
$(".accordion-titulo").click(function(e){
       
    e.preventDefault();

    var contenido=$(this).next(".accordion-content");
    
    if(contenido.css("display")=="none"){ //open		
      contenido.slideDown(250);			
      $(this).addClass("open");
    }
    else{ //close		
      contenido.slideUp(250);
      $(this).removeClass("open");	
    }
  });

  
  
});


// acordeón y Cambio de img servicios

function init(){
    var ccomercioElectronico = document.getElementById("ccomercioElectronico");
    var cestrategiaConsultoria = document.getElementById("cestrategiaConsultoria");
    var crendmiento = document.getElementById("crendmiento");
    ccomercioElectronico.style.display = "block";
    cestrategiaConsultoria.style.display = "none";
    crendmiento.style.display = "none";  
}


function imgComercioElectronico(){
    
    document.getElementById("imgServicios").src="../PRUEBA/images/img-comercio-electronico.jpg";

    var icost1 = document.getElementById("ico-st1");
    var icost2 = document.getElementById("ico-st0");
    var icost3 = document.getElementById("ico-st0-2");
    if (icost1.style.fill === '#8d2d89'){
        icost1.style.fill = "#e66225";
        icost2.style.fill = "#ffffff";
        icost3.style.fill = "#ffffff";
    }else{
        icost1.style.fill = "#e66225";
        icost2.style.fill = "#ffffff";
        icost3.style.fill = "#ffffff";
    }
   
};

function fComercioElectronico(){
    var ccomercioElectronico = document.getElementById("ccomercioElectronico");
    var cestrategiaConsultoria = document.getElementById("cestrategiaConsultoria");
    var crendmiento = document.getElementById("crendmiento");

    if (ccomercioElectronico.style.display === "none") {
        //ccomercioElectronico.style.display = "block";
        cestrategiaConsultoria.style.display = "none";
        crendmiento.style.display = "none";   
    } else {
        ccomercioElectronico.style.display = "none";
        cestrategiaConsultoria.style.display = "none";
        crendmiento.style.display = "none";        
    }
};



function imgEstrategiaConsultoria(){
    document.getElementById("imgServicios").src="../PRUEBA/images/img-estrategia-consultoria.jpg";
    var icost1 = document.getElementById("ico-st1");
    var icost2 = document.getElementById("ico-st0");
    var icost3 = document.getElementById("ico-st0-2");
    if (icost1.style.fill = "#e66225"){
        icost1.style.fill = "#8d2d89";
        icost2.style.fill = "#434041";
        icost3.style.fill = "#434041";
    }else if(icost1.style.fill = "#8d2d89"){
        icost1.style.fill = "#e66225";
    }
};

function festrategiaConsultoria(){
    var ccomercioElectronico = document.getElementById("ccomercioElectronico");
    var cestrategiaConsultoria = document.getElementById("cestrategiaConsultoria");
    var crendmiento = document.getElementById("crendmiento");

    if (cestrategiaConsultoria.style.display === "none") {
        ccomercioElectronico.style.display = "none";
        //cestrategiaConsultoria.style.display = "block";
        crendmiento.style.display = "none";   
    } else {
        ccomercioElectronico.style.display = "none";
        cestrategiaConsultoria.style.display = "none";
        crendmiento.style.display = "none";        
    }
};

function imgRendmiento(){
    document.getElementById("imgServicios").src="../PRUEBA/images/img-rendimiento.jpg";
    var icost1 = document.getElementById("ico-st1");
    var icost2 = document.getElementById("ico-st0");
    var icost3 = document.getElementById("ico-st0-2");
    if (icost1.style.fill === '#8d2d89'){
        icost1.style.fill = "#e66225";
        icost2.style.fill = "#ffffff";
        icost3.style.fill = "#ffffff";
    }else{
        icost1.style.fill = "#e66225";
        icost2.style.fill = "#ffffff";
        icost3.style.fill = "#ffffff";
    }
};

function frendmiento(){
    var ccomercioElectronico = document.getElementById("ccomercioElectronico");
    var cestrategiaConsultoria = document.getElementById("cestrategiaConsultoria");
    var crendmiento = document.getElementById("crendmiento");

    if (crendmiento.style.display === "none") {
        ccomercioElectronico.style.display = "none";
        cestrategiaConsultoria.style.display = "none";
       // crendmiento.style.display = "block";   
    } else {
        ccomercioElectronico.style.display = "none";
        cestrategiaConsultoria.style.display = "none";
        crendmiento.style.display = "none";        
    }
};

init();

// fin acordeón y Cambio de img servicios




// links
function imglink(){
    document.getElementById("link-text").src="../PRUEBA/images/arrow-down-julius1.svg";
    var fil1 = document.getElementById("fil-1");
    fil1.style.fill = '#8d2d89';
};
function imglink2(){
    document.getElementById("link-text").src="../PRUEBA/images/arrow-down-julius2.svg";
    var fil1 = document.getElementById("fil-1");
    fil1.style.fill = '#e66225';
};